
import MainContent from "../components/layout/MainContent";

export default function Home() {
  return <MainContent />;
}